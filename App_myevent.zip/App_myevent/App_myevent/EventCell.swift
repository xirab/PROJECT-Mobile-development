//
//  EventCell.swift
//  App_myevent
//
//  Created by goldorak on 07/02/2022.
//

import Foundation
import UIKit


class EventCell{
    
}
